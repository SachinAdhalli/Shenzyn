from django.db import models
from datetime import datetime
#from settings import *


# Create your models here.

class Todo(models.Model):
      title = models.CharField(max_length=120, blank=False)
      description = models.TextField(blank=False)
      completed = models.BooleanField(default=False)
      startDate = models.DateField(null=True)
      #startDate = forms.DateField(input_formats=['%d/%m/%Y'])
      endDate = models.DateField(null=True )
      

      def _str_(self):
        return self.title
