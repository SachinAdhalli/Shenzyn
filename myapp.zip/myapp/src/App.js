
/*function App(props) {
  var curr = new Date();
  curr.setDate(curr.getDate());
  var date = curr.toISOString().substr(0,10);

  return (
      <div className="row " >
        <label >TITLE:</label>
          <input type="text" name="list" ></input>
            <br>
            </br>
          <label >Start Date:</label>
          <input id="date" type="date" name="date" defaultValue={date} />
            <br>
            </br>
            <label >Due Date:</label>
          <input type="date" name="due" ></input>
            <br>
            </br>
            <label>Description:</label>
          <input type="text" name="desc" ></input>
            <br>
            </br>
          <label for="completed">
                  <input
                    type="checkbox"
                    name="completed"
                    //checked={this.state.activeItem.completed}
                    //onChange={this.handleChange}
                  />
                  Completed
            </label>
          <input type="submit" value="Submit"></input>
      </div>
  );
  
}

export default App;

//django
//django rest framework
*/



import React, { Component } from "react";
import Modal from "./components/Modal";
import axios from "axios";

import Noty from 'noty'; 
import "../node_modules/noty/lib/noty.css"; 
import "../node_modules/noty/lib/themes/mint.css";

    class App extends Component {
      constructor(props) {
        super(props);
        this.state = {
          viewCompleted: false,
          activeItem: {
            title: "",
            startDate: null,
            endDate: null,
            description: "",
            completed: false
          },
          todoList: []
        };
      }
      componentDidMount() {
        this.refreshList();
      }
      refreshList = () => {
        axios
          .get("/api/todos/")
          .then(res => this.setState({ todoList: res.data }))
          .catch(err => console.log(err));
          console.log('get request received')
      };
      displayCompleted = status => {
        if (status) {
          return this.setState({ viewCompleted: true });
        }
        return this.setState({ viewCompleted: false });
      };
      renderTabList = () => {
        return (
          <div className="my-5 tab-list">
            <span
              onClick={() => this.displayCompleted(true)}
              className={this.state.viewCompleted ? "active" : ""}
            >
              complete
            </span>
            <span
              onClick={() => this.displayCompleted(false)}
              className={this.state.viewCompleted ? "" : "active"}
            >
              Incomplete
            </span>
          </div>
        );
      };
      renderItems = () => {
        const { viewCompleted } = this.state;
        const newItems = this.state.todoList.filter(
          item => item.completed === viewCompleted
        );
        return newItems.map(item => (
          <li
            key={item.id}
            className="list-group-item d-flex justify-content-between align-items-center"
          >
            <span
              className={`todo-title mr-2 ${
                this.state.viewCompleted ? "completed-todo" : ""
              }`}
              title={item.description}
            >
              {item.title}
            </span>
            <span>
              <button
                onClick={() => this.editItem(item)}
                className="btn btn-secondary mr-2"
              >
                Edit
              </button>
              <button
                onClick={() => this.handleDelete(item)}
                className="btn btn-danger"
              >
                Delete
              </button>
            </span>
          </li>
        ));
      };
      toggle = () => {
        this.setState({ modal: !this.state.modal });
      };
      handleSubmit = item => {
        this.toggle();
        if (item.id) {
          axios
            .put(`http://localhost:8000/api/todos/${item.id}/`, item)
            .then(res => this.refreshList());
          return;
        }

        // axios
        //   .post("http://localhost:8000/api/todos/", item)
        //   .then(res => this.refreshList())
        //   .catch(err => {
        //     console.log(err.response.data);
        //     new Noty({
        //       text: `<h3>${err.response.data.title}</h3><p>${
        //         err.response.data.description
        //       }</p>`,
        //       layout: "top",
        //       theme: "bootstrap-v4"
        //     }).show();
        //   });

        axios
          .post("http://localhost:8000/api/todos/", item)
          .then(res => this.refreshList())
          .catch(err => console.log(err.response.data))
          //.catch(err => console.log(JSON.stringify(err, null, 2)))
          //console.log('add request received')          
      };
      handleDelete = item => {
        axios
          .delete(`http://localhost:8000/api/todos/${item.id}/`)
          .then(res => this.refreshList());
      };
      createItem = () => {
        const item = { title: "", description: "", startDate: null, endDate: null, completed: false };  //startDate: null, endDate: null,
        this.setState({ activeItem: item, modal: !this.state.modal });
      };
      editItem = item => {
        this.setState({ activeItem: item, modal: !this.state.modal });
      };
      render() {
        return (
          <main className="content">
            <h1 className="text-white text-uppercase text-center my-4">Todo app</h1>
            <div className="row ">
              <div className="col-md-6 col-sm-10 mx-auto p-0">
                <div className="card p-3">
                  <div className="">
                    <button onClick={this.createItem} className="btn btn-primary">
                      Add task
                    </button>
                  </div>
                  {this.renderTabList()}
                  <ul className="list-group list-group-flush">
                    {this.renderItems()}
                  </ul>
                </div>
              </div>
            </div>
            {this.state.modal ? (
              <Modal
                activeItem={this.state.activeItem}
                toggle={this.toggle}
                onSave={this.handleSubmit}
              />
            ) : null}
          </main>
        );
      }
    }
    export default App;
